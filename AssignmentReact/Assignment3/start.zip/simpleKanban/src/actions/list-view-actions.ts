import * as Immutable from 'immutable';
import axios from 'axios';

import {Card, ICard} from '../data/card';
import {Task, ITask} from '../data/task';

const API_URL = 'https://react-spring-2017-server-winwust.c9users.io:8080/api';

export function getListView(): any {
    return (dispatch: any) => {
        dispatch(requestListView());
        
        axios.get(`${API_URL}/cards`)
        .then(
            (response: any) => {
                const result: Immutable.List<Card> = 
                    processResponseData(response.data)
                dispatch(receiveListViewSuccess(result));
            }
        )
        .catch(
            (error) => {
                dispatch(receiveListViewFailure());
            }
        );
    }
}

function processResponseData(
    serverSideData: Array<ICard>
): Immutable.List<Card> {
    return Immutable.List<Card>(
        serverSideData.map(
            (card: ICard) => {
                const tasks: Immutable.List<Task> =
                    Immutable.List<Task>(
                        card.tasks.map(
                            (task: ITask) => {
                                return new Task((Object as any).assign(
                                    {}, 
                                    task,
                                    {
                                        id: task._id,
                                        _id: undefined
                                    }
                                ))
                            }
                        )
                    );
                return new Card((Object as any).assign(
                    {}, 
                    card,
                    {
                        id: card._id,
                        _id: undefined,
                        tasks: tasks
                    }
                ));
            }
        )
    );
}

function requestListView(): any {
    return {
        type: 'REQUEST_LIST_VIEW'
    };
}

function receiveListViewSuccess(
    data: Immutable.List<Card>
): any {
    return {
        type: 'RECEIVE_LIST_VIEW_SUCCESS',
        payload: data
    };
}

function receiveListViewFailure(): any {
    return {
        type: 'RECEIVE_LIST_VIEW_FAILURE'
    };
}