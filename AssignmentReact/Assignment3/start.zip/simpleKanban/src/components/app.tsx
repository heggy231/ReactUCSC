import * as React from 'react';

import * as ListViewReducer from '../reducers/list-view-reducer';

import ListView from './list-view';

interface AppProps {
    listView: ListViewReducer.ListViewState,
    
    getListView: any
}

export default class App extends React.Component<AppProps, {}> {
    displayListView(): JSX.Element {
        return (
            <ListView
                listView = {this.props.listView}
                getListView = {this.props.getListView}
            />
        );
    }
    
    render(): JSX.Element {
        return (
            <div>
                {
                    this.displayListView()
                }
            </div>
        );
    }
}