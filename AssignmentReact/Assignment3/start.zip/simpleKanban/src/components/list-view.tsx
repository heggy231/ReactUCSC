import * as React from 'react';
import * as Immutable from 'immutable';

import * as ListViewReducer from '../reducers/list-view-reducer';

import {Card} from '../data/card';

interface ListViewProps {
    listView: ListViewReducer.ListViewState,
    
    getListView: any    
}

export default class ListView extends React.Component<ListViewProps, {}> {
    componentDidMount() {
        this.props.getListView();
    }
    
    showListViewLoading(): JSX.Element {
        if (this.props.listView.get('loading')) {
            return <div className="loading">Loading data...</div>;
        } else {
            return null;
        }
    }
    
    showListViewError(): JSX.Element {
        if (this.props.listView.get('error')) {
            return (
                <div className="error">
                {
                    this.props.listView.get('error')
                }
                </div>
            );
        } else {
            return null;
        }
    }
    
    showListViewData(): Array<JSX.Element> {
        const data: Immutable.List<Card> = 
            this.props.listView.get('data');
        if (data) {
            return data.map(
                (card: Card) => {
                    return (
                        <div className="card">
                        {
                            card.get('title')
                        }
                        </div>
                    );
                }
            );
        } else {
            return null;
        }
    }
    
    render(): JSX.Element {
        return (
            <div>
                {
                    this.showListViewLoading()
                }
                {
                    this.showListViewData()
                }
                {
                    this.showListViewError()
                }
            </div>
        );
    }
}