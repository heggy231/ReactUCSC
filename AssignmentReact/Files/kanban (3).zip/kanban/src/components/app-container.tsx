import * as Immutable from 'immutable';
import {connect} from 'react-redux';

import {Card} from '../data/card';
import App from './app';

interface AppState {
    cards: Immutable.List<Card>
}

const mapStateToProps = (state: AppState) => state;
const mapDispatchToProps = (dispatch: any) => {
    return {}
};

const AppContainer = connect(
    mapStateToProps, 
    mapDispatchToProps
)(App);

export default AppContainer;