import * as React from 'react';
import * as Immutable from 'immutable';

import {Card} from '../data/card';
import List from './list';

interface KanbanBoardProps {
    cards: Immutable.List<Card>
}

export default class KanbanBoard 
    extends React.Component<KanbanBoardProps, {}> {

    render(): JSX.Element {
        return (
            <div>
                <List
                    title = "To Do"
                    cards = {
                        Immutable.List(
                            this.props.cards.filter(
                                (card: Card) => card.get('status') === 'todo'
                            )
                        )
                    }
                />
                <List
                    title = "In Progress"
                    cards = {
                        Immutable.List(
                            this.props.cards.filter(
                                (card: Card) => card.get('status') === 'in-progress'
                            )
                        )
                    }
                />
                <List
                    title = "Done"
                    cards = {
                        Immutable.List(
                            this.props.cards.filter(
                                (card: Card) => card.get('status') === 'done'
                            )
                        )
                    }
                />
            </div>
        )
    }
}