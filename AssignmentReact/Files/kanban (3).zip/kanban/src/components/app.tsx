import * as React from 'react';
import * as Immutable from 'immutable';

import {Card} from '../data/card';

import KanbanBoard from './kanban-board';

interface AppProps {
    cards: Immutable.List<Card>;
}

export default class App extends React.Component<AppProps, {}> {
    render(): JSX.Element {
        return (
            <div>
                <h1>Kanban Board</h1>
                <KanbanBoard
                    cards = {this.props.cards}
                />
            </div>
        )
    }
}