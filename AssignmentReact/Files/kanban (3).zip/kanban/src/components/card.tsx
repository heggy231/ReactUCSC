import * as React from 'react';
import * as Immutable from 'immutable';

import {Card} from '../data/card';
import {Task} from '../data/task';

import CheckList from './check-list';

interface KardProps {
    title: string;
    description: string;
    tasks: Immutable.List<Task>;
}

export default class Kard extends React.Component<KardProps, {}> {
    render(): JSX.Element {
        return (
            <div className='card'>
                <div className = 'card_title'>
                    {this.props.title}
                </div>
                <div>{this.props.description}</div>
                <CheckList
                    tasks = {this.props.tasks}
                />
            </div>
        );
    }
}