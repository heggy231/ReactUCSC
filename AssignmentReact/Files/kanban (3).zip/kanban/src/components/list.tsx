import * as React from 'react';
import * as Immutable from 'immutable';

import {Card} from '../data/card';
import Kard from './card';

interface ListProps {
    title: string;
    cards: Immutable.List<Card>;
}

export default class List extends React.Component<ListProps, {}> {
    render(): JSX.Element {
        return(
            <div>
                <h1>{this.props.title}</h1>
                <div>
                    {
                        this.props.cards.map(
                            (card: Card) => {
                                return (
                                    <Kard
                                        key = {card.get('id')}
                                        title = {card.get('title')}
                                        description = {card.get('description')}
                                        tasks = {card.get('tasks')}
                                    />
                                )
                            }
                        ).toArray()
                    }
                </div>
            </div>
        )
    }
}