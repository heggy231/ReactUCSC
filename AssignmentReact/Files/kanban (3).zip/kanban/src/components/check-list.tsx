import * as React from 'react';
import * as Immutable from 'immutable';

import {Task} from '../data/task';

interface CheckListProps {
    tasks: Immutable.List<Task>;
}

export default class CheckList extends React.Component<CheckListProps, {}> {
    render(): JSX.Element {
        return (
            <div>
                <ul>
                {
                    this.props.tasks.map(
                        (task: Task) => {
                            return (
                                <li
                                    key = {task.get('id')}
                                    className = 'checklist_task'
                                >
                                    <span>{task.get('name')}</span>
                                </li>
                            )
                        }
                    )
                }
                </ul>
            </div>
        );
    }
}