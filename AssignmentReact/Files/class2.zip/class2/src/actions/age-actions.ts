export function increase(): any {
    return {
        type: "INCREASE_AGE"
    };
}

export function decrease(): any {
    return {
        type: "DECREASE_AGE"
    };
}