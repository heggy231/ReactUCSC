import {combineReducers} from 'redux';

import * as CardReducer from './card-reducer';

const indexReducer = combineReducers({
    cards: CardReducer.reduce,
});

export default indexReducer;