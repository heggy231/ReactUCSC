import * as React from 'react';

import * as ListViewReducer from '../reducers/list-view-reducer';

interface ListViewProps {
    listView: ListViewReducer.ListViewState,
    
    getListView: any    
}

export default class ListView extends React.Component<ListViewProps, {}> {
    componentDidMount() {
        this.props.getListView();
    }
    
    render(): JSX.Element {
        return null;
    }
}