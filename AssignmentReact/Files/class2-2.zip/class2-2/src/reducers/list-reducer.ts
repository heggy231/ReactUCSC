import * as Immutable from 'immutable'

export function reduce(
    state: Immutable.List<string> = Immutable.List<string>(),
    action: any
): Immutable.List<string> {
    switch (action.type) {
        case "UPDATE_LIST":
            const name = action.payload;
            return state.push(name);
        default: 
            return state;
    }
}