import * as Immutable from 'immutable';

import * as React from 'react';

interface AppProps {
    nameEntry: string;
    nameList: Immutable.List<string>;
    
    appChangeName: any;
    appUpdateList: any;
}

export default class App extends React.Component<AppProps, {}> {
    render(): JSX.Element {
        return (
        <div>
            <input
                className = "form-control"
                type = "text"
                value = {this.props.nameEntry}
                onChange = {
                    (evt) => {
                        this.props.appChangeName(
                            (evt.target as any).value
                        )
                    }
                }
            />
            <input
                className = "form-control"
                type = "button"
                value = "Add Name"
                onClick = {
                    (evt) => {
                        this.props.appUpdateList(
                            this.props.nameEntry
                        )
                    }
                }
            />
        </div>
        );
    }
}