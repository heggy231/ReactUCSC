export function toggleTask(
    cardId: string,
    taskId: string
): any {
    return {
        type: 'TOGGLE_TASK',
        payload: {
            cardId: cardId,
            taskId: taskId
        }
    };
}