import * as React from 'react';
import * as Immutable from 'immutable';

import {Task} from '../data/task';

interface CheckListProps {
    tasks: Immutable.List<Task>;
    
    handleToggleTask: any;
}

export default class CheckList extends React.Component<CheckListProps, {}> {
    render(): JSX.Element {
        const that = this;
        return (
            <div>
                <ul>
                {
                    this.props.tasks.map(
                        (task: Task) => {
                            return (
                                <li
                                    key = {task.get('id')}
                                    className = 'checklist_task'
                                >
                                    <input
                                        type = "checkbox"
                                        checked = {task.get('done')}
                                        onChange = {
                                            (evt) => that.props.handleToggleTask(task.get('id'))
                                        }
                                    />
                                    <span>{task.get('name')}</span>
                                </li>
                            )
                        }
                    )
                }
                </ul>
            </div>
        );
    }
}