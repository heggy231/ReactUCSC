import * as React from 'react';
import * as Immutable from 'immutable';

import {Card} from '../data/card';
import {Task} from '../data/task';

import CheckList from './check-list';

interface KardProps {
    id: string;
    title: string;
    description: string;
    tasks: Immutable.List<Task>;
    
    toggleTask: any;
}

export default class Kard extends React.Component<KardProps, {}> {

    handleToggleTask(taskId: string) {
        this.props.toggleTask(
            this.props.id,
            taskId
        );
    }

    render(): JSX.Element {
        return (
            <div className='card'>
                <div className = 'card_title'>
                    {this.props.title}
                </div>
                <div>{this.props.description}</div>
                <CheckList
                    tasks = {this.props.tasks}
                    
                    handleToggleTask = {this.handleToggleTask.bind(this)}
                />
            </div>
        );
    }
}