const cards = [
    {
        id: 'card1',
        title: 'Read react book',
        description: 'I should read the book before class',
        status: 'in-progress',
        tasks: []
    },
    {
        id: 'card2',
        title: 'Write some code',
        description: 'Practice coding skill',
        status: 'todo',
        tasks: [
            {
                id: 'card2task1',
                name: 'hello world example',
                done: true
            },
            {
                id: 'card2task2',
                name: 'Kanban example',
                done: false
            },
            {
                id: 'card2task3',
                name: 'Assignments',
                done: false
            }
        ]
    }
];

import * as Immutable from 'immutable';

import {ICard, Card} from '../data/card';
import {ITask, Task} from '../data/task';

function createInitialState(
    cardState: Array<ICard>
): Immutable.List<Card> {
    
    const cards: Array<Card> = cardState.map(
        (card: ICard) => {
            const tasks: Array<Task> = card.tasks.map(
                (task: ITask) => new Task(task)
            );
            
            return new Card(
                (Object as any).assign({}, card, {
                    tasks: Immutable.List(tasks)
                })
            );
        }
    );
    return Immutable.List<Card>(cards);
}

export function reduce(
    state: Immutable.List<Card> = createInitialState(cards),
    action: any
): Immutable.List<Card> {
    switch (action.type) {
        case 'TOGGLE_TASK':
            const cardId: string = action.payload.cardId;
            const taskId: string = action.payload.taskId;
            
            const cardIndex: number =
                state.findIndex(
                    (card: Card) => card.get('id') === cardId
                );
            const currentCard: Card = state.get(cardIndex);
            const taskIndex: number =
                currentCard.get('tasks').findIndex(
                    (task: Task) => task.get('id') === taskId
                );
            const currentDone: boolean = state.getIn(
                [cardIndex, 'tasks', taskIndex, 'done']
            );
            return state.setIn(
                [cardIndex, 'tasks', taskIndex, 'done'],
                !currentDone
            );
        default:
            return state;
    }
}