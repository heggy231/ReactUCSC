import * as React from 'react';
import * as ReactDOM from 'react-dom';

import Greet from './greet';

ReactDOM.render(
    <Greet
        firstName = "Jack"
        lastName = "Jones"
    />,
    document.getElementById('app')
);