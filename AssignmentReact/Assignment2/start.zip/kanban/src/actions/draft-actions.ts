export function openDraft() {
    return {
        type: 'OPEN_DRAFT'
    };
}

export function closeDraft() {
    return {
        type: 'CLOSE_DRAFT'
    };
}